const http = require('http');
const url = require('url');
const data      = require('./data');

exports.search = function (req, res) {
    const reqUrl = url.parse(req.url, true);
    let param = reqUrl.query.param;
    
    var response = param ? data.filter(
        item => {
            return item.name.toLowerCase().indexOf(param.toLowerCase())>0
        }).map(item => { return item }) : [];
        const headers = {
            'Access-Control-Allow-Origin': '*',
            'Access-Control-Allow-Methods': 'OPTIONS, POST, GET',
            'Content-Type': 'application/json',
    
            /** add other headers as per requirement */
          };
          res.writeHead(200, headers);
                 res.statusCode = 200;

   /*  
    res.setHeader('Access-Control-Allow-Origin', '*');
    res.setHeader('Access-Control-Allow-Methods', 'GET, POST, OPTIONS, PUT, PATCH, DELETE'); // If needed
    res.setHeader('Access-Control-Allow-Headers', 'X-Requested-With,content-type'); // If needed
    res.setHeader('Access-Control-Allow-Credentials', true); // If needed */
    res.end(JSON.stringify(response));
};